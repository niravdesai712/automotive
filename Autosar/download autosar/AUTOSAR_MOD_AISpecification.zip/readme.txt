This archive contains the following files:

readme.txt
    This file

AUTOSAR_MOD_AISpecification_Standard.arxml
    This AUTOSAR STANDARD file provides standardized definitions of Units,
    Physical Dimensions and Data Constraints.

AUTOSAR_MOD_AISpecification_Blueprint.arxml
    This AUTOSAR STANDARD file provides Blueprint Definitions of Port
    Prototype Blueprints, the associated Port Interfaces, Application Data
    Types and their related Compu Methods. Blueprints are not intented
    to be used 'as is'; rather concrete projects derive individual
    elements based on the blueprint definitions, possibly adding
    information in order to come to complete definitions of the derived
    elements.
   
AUTOSAR_MOD_AISpecification_Example.arxml
    This AUXILIARY file provides a set of Composition Software Component
    Types and associated elements exemplary showing the interconnection
    of the Port Blueprints derived from the blueprint definitions found
    in the Blueprint ARXML file. Blueprint Mapping Sets provide the
    required mappings to the Blueprints.
    
AUTOSAR_MOD_AISpecification_Keyword.arxml
    This AUXILIARY file provides keyword definitions used for composing
    short names throughout the AI Specification.