Document Title:                 Foundation UML Model
Document Owner:                 AUTOSAR
Document Responsibility:        AUTOSAR
Document Identification Number: 877
Document Status:                Final
Part of AUTOSAR Standard:       Foundation
Part of Standard Release:       1.3.0
Date:                           2017-12-08
